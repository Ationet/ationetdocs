﻿using AtionetMPPAExample.MPPAHostRequest;
using AtionetMPPAExample.MPPAHostResponse.ResponseEvents;
using AtionetMPPAExample.MPPAHostResponse.ResponseEvents.EventsTypes;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net.ServerSentEvents;
using System.Net.Sockets;
using System.Text;
namespace AtionetMPPAExample
{
    internal class MPPAClientWorker : BackgroundService
    {
        private readonly ILogger<MPPAClientWorker> _logger;
        private readonly MPPAHost _hostConfigurations;
        private static HttpClient _httpClient;
        private string basicURL = string.Empty;
        private string siteSessionId;
        public MPPAClientWorker(MPPAHost configuration, ILogger<MPPAClientWorker> logger)
        {
            _hostConfigurations = configuration;
            _logger = logger;
            _logger.LogInformation("Iniciando MPPACLientWorker");

        }
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            this.CreateHTTP();
            this.InitHTTPClient();
        }

        private void CreateHTTP()
        {
            var authenticationString = $"{_hostConfigurations.Username}:{_hostConfigurations.Password}";
            string base64EncodedAuthenticationString;

            base64EncodedAuthenticationString = Convert.ToBase64String(Encoding.UTF8.GetBytes(authenticationString));

            // allow to connect to self-signed certificate ssl
            var handler = new HttpClientHandler
            {
                ClientCertificateOptions = ClientCertificateOption.Manual,
                ServerCertificateCustomValidationCallback = (httpRequestMessage, cert, cetChain, policyErrors) => true
            };

            _httpClient = new HttpClient(handler);
            _httpClient.DefaultRequestHeaders.Add("Authorization", "Basic " + base64EncodedAuthenticationString);
            _httpClient.Timeout = TimeSpan.FromSeconds(_hostConfigurations.Timeout);
            this.basicURL = _hostConfigurations.URL + _hostConfigurations.Controller;
        }

        /// <summary>
        /// Initilizes the HTTP Client that is used 
        /// </summary>
        private void InitHTTPClient()
        {
            var retries = 0;

            while (retries <= 3)
            {
                if (!this.Connection()) //1 - POST
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    _logger.LogError("Connection method failed. Retries: {0}", retries);
                    Console.ResetColor();

                    retries++;
                }
                else
                {
                    break;
                }
            }

            this.MobileEvents(); //2 - GET

            retries = 0;

            while (retries <= 3)
            {
                if (!this.SiteData()) //3 - POST
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    _logger.LogError("SiteData failed. Retries: {0}", retries);
                    Console.ResetColor();

                    retries++;
                }
                else
                {
                    break;
                }
            }

            retries = 0;

            while (retries <= 3)
            {
                if (!this.Products()) //4 - POST
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    _logger.LogError("Products method failed. Retries: {0}", retries);
                    Console.ResetColor();

                    retries++;
                }
                else
                {
                    break;
                }
            }

            retries = 0;

            while (retries <= 3)
            {
                if (!this.DSPS()) //5 - POST
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    _logger.LogError("DSPS method failed. Retries: {0}", retries);
                    Console.ResetColor();

                    retries++;
                }
                else
                {
                    break;
                }
            }

            this.SSE(); //6 - GET
        }


        /// <summary>
        /// "This call should be made every 45 seconds and it works as a heartbeat. If no response is received, the channel should be closed and the connection restarted.
        /// </summary>
        /// <returns></returns>
        public bool Connection()
        {
            var url = this.basicURL + "/connection";
            var connection = new Connection
            {
                applicationSender = _hostConfigurations.SiteCode,
                interfaceVersion = "1.0",
                timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss"),
                workstationID = _hostConfigurations.SiteCode
            };
            var content = new StringContent(JsonConvert.SerializeObject(connection), Encoding.UTF8, "application/json");

            Console.ForegroundColor = ConsoleColor.Blue;
            _logger.LogInformation("** Sending HTTP Connection ** \r\n");
            _logger.LogDebug("Url: {0}", url);
            _logger.LogDebug("Content: {0}", content.ReadAsStringAsync().Result);
            Console.ResetColor();

            return PostStringAsync(url, content).Result;
        }

        /// <summary>
        /// This method returns the URL with which the SSE (Server-Sent Events) communication is established.
        /// </summary>
        /// <returns></returns>
        public bool MobileEvents()
        {
            var url = this.basicURL + "/MobileEvents";

            Console.ForegroundColor = ConsoleColor.Blue;
            _logger.LogInformation("** Sending HTTP MobileEvents ** \r\n");
            _logger.LogDebug("Url: {0}", url);
            Console.ResetColor();

            var body = GetStringAsync(url).Result;
            var result = JsonConvert.DeserializeObject<MobileEvent>(body);

            Console.ForegroundColor = ConsoleColor.Blue;
            _logger.LogDebug("Content: {0}", body);
            Console.ResetColor();

            if (result != null && result.errorCode == "ERRCD_OK")
            {
                siteSessionId = new Uri(result.url).Segments[4];

                return true;
            }

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool SiteData()
        {
            var url = this.basicURL + "/SSE/" + siteSessionId + "/siteData";

            Console.ForegroundColor = ConsoleColor.Blue;
            _logger.LogInformation("** Sending HTTP SiteData ** \r\n");
            _logger.LogDebug("Url: {0}", url);
            Console.ResetColor();

            var siteId = new SiteID { id = _hostConfigurations.SiteCode, type = "SHIPTO" };
            var siteIDs = new List<SiteID>();
            siteIDs.Add(siteId);

            var siteData = new SiteData { name = "IFSF/Conexxus Station", siteIDs = siteIDs, addressLines = new List<string> { "1835 112th Av.", "Suite 170" } };
            var content = new StringContent(JsonConvert.SerializeObject(siteData), Encoding.UTF8, "application/json");

            return PostStringAsync(url, content).Result;
        }

        /// <summary>
        /// This method sends products information. This information must be obtained from the site system.
        /// </summary>
        /// <returns></returns>
        public bool Products()
        {
            var url = this.basicURL + "/SSE/" + siteSessionId + "/products";


            #region Obtain Controller Values
            //En este punto hay que obtener los datos del controlador para configurar la sesión

            var fuelProduct1 = new FuelProduct
            {
                ProductCode = "CODE1",
                ProductNo = "1",
                ProductName = "Premium",
                FuelPrice = new FuelPrice { Currency = "USD", Value = "20" },
                FuelUnitOfMeasurement = "LTRS"
            };

            var fuelProduct2 = new FuelProduct
            {
                ProductCode = "CODE2",
                ProductNo = "2",
                ProductName = "DIESEL",
                FuelPrice = new FuelPrice { Currency = "USD", Value = "10" },
                FuelUnitOfMeasurement = "LTRS"
            };

            var fuelProducts = new FuelProducts { fuelProducts = new List<FuelProduct>() };

            fuelProducts.fuelProducts.Add(fuelProduct1);
            fuelProducts.fuelProducts.Add(fuelProduct2);
            #endregion

            var content = new StringContent(JsonConvert.SerializeObject(fuelProducts, Newtonsoft.Json.Formatting.None), Encoding.UTF8, "application/json");

            Console.ForegroundColor = ConsoleColor.Blue;
            _logger.LogInformation("** Sending HTTP Products ** \r\n");
            _logger.LogDebug("Url: {0}", url);
            _logger.LogDebug("Content: {0}", content.ReadAsStringAsync().Result);
            Console.ResetColor();

            return PostStringAsync(url, content).Result;
        }

        /// <summary>
        /// This method sends dispensers information. This information must be obtained from the site system.
        /// </summary>
        /// <returns></returns>
        public bool DSPS()
        {

            #region Obtain Controller Values
            var url = this.basicURL + "/SSE/" + siteSessionId + "/dsps";
            var fuelingPoints = new FuelingPoint();
            var dispenserConfiguration = new DispensersConfiguration();

            fuelingPoints.fuelingPointID = "1";

            fuelingPoints.nozzles = new List<Nozzle>();
            fuelingPoints.nozzles.Add(new Nozzle { nozzleNo = "1", productNo = "1", tankNo1 = "1" });
            fuelingPoints.nozzles.Add(new Nozzle { nozzleNo = "2", productNo = "2", tankNo1 = "2" });

            dispenserConfiguration.dispenserID = "1";
            dispenserConfiguration.fuelingPoints = new List<FuelingPoint>();
            dispenserConfiguration.fuelingPoints.Add(fuelingPoints);

            var dispenserconfigurations = new DispensersConfigurations();

            dispenserconfigurations.dispensersConfiguration = new List<DispensersConfiguration>();
            dispenserconfigurations.dispensersConfiguration.Add(dispenserConfiguration);
            #endregion

            Console.ForegroundColor = ConsoleColor.Blue;
            _logger.LogInformation("** Sending HTTP DSPS ** \r\n");
            _logger.LogDebug("Url: {0}", url);
            Console.ResetColor();

            var content = new StringContent(JsonConvert.SerializeObject(dispenserconfigurations), Encoding.UTF8, "application/json");

            return PostStringAsync(url, content).Result;


        }

        /// <summary>
        /// This method establishes a SSE connection
        /// </summary>
        public void SSE()
        {
            var url = this.basicURL + "/SSE/" + siteSessionId;

            Console.ForegroundColor = ConsoleColor.Blue;
            _logger.LogInformation("** Sending HTTP SSE ** \r\n");
            _logger.LogDebug("Url: {0}", url);
            Console.ResetColor();

            _httpClient.DefaultRequestHeaders.Add("Connection", "keep-alive");
            _ = GetStreamAsync(url);
        }

        /// <summary>
        /// HTTP Client GET operation
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        private async Task<string> GetStringAsync(string url)
        {
            try
            {
                CancellationToken cancellationToken = default;

                using (var response = await _httpClient.GetAsync(url, cancellationToken))
                {
                    if (!response.IsSuccessStatusCode)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        _logger.LogError(response.Content.ReadAsStringAsync().Result);
                        Console.ResetColor();

                        response.EnsureSuccessStatusCode();
                    }

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (HttpRequestException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;

                _logger.LogError("URL:{0} - TRACE {1}", url, ex.ToString());

                Console.ResetColor();
                return string.Empty;
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;

                _logger.LogError("URL:{0} - TRACE {1}", url, ex.ToString());

                Console.ResetColor();
                return string.Empty;
            }
        }

        /// <summary>
        /// HTTP Client GET Stream operation (SSE)
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        private async Task<string> GetStreamAsync(string url)
        {
            try
            {
                CancellationToken cancellationToken = default;

                var stream = _httpClient.GetStreamAsync(url, cancellationToken).Result;

                await foreach (SseItem<string> item in SseParser.Create(stream).EnumerateAsync())
                {
                    _logger.LogDebug($"Receiving message {item.EventType}");

                    Console.ForegroundColor = ConsoleColor.Green;

                    //Obtiene los mensajes enviados por el servidor 
                    if (string.IsNullOrEmpty(item.Data))
                    {
                        throw new Exception("Data cannot be null or empty");
                    }
                    try
                    {
                        switch (item.EventType)
                        {
                            case EventType.KEEP_ALIVE:
                                _logger.LogDebug("Keep Alive event detected: ({0})", item.Data);
                                KeepAliveEvent keepAliveEvent = System.Text.Json.JsonSerializer.Deserialize<KeepAliveEvent>(item.Data);
                                break;
                            case EventType.FP_RESERVE_REQUEST:
                                _logger.LogDebug("Fueling Point Reserve message detected: ({0})", item.Data);
                                FuelingPointReserveRequestEvent fuelingPointReserveRequestEvent = System.Text.Json.JsonSerializer.Deserialize<FuelingPointReserveRequestEvent>(item.Data);
                                break;
                            case EventType.FP_RESERVE_CANCEL_REQUEST:
                                _logger.LogDebug("Fueling Point Reserve cancel message detected: ({0})", item.Data);
                                FuelingPointReserveCancelRequestEvent fuelingPointReserveCancelRequestEvent = System.Text.Json.JsonSerializer.Deserialize<FuelingPointReserveCancelRequestEvent>(item.Data);
                                break;
                            case EventType.AUTHORIZE_REQUEST:
                                _logger.LogDebug("Authorize Request message detected: ({0})", item.Data);
                                AuthorizeRequestEvent authorizeRequestEvent = System.Text.Json.JsonSerializer.Deserialize<AuthorizeRequestEvent>(item.Data);
                                break;
                            case EventType.TRANSACTION_DATA_REQUEST:
                            case EventType.CLOSE_TRX_REQUEST:
                            case EventType.SITE_DATA_REQUEST:
                            case EventType.CANCEL_TRX_REQUEST:
                            default:
                                throw new Exception($"Event Type Not Supported for this implementation. Type of event received {item.EventType}");
                        }

                        Console.ResetColor();

                    }
                    catch
                    {
                        throw;
                    }
                }
                return string.Empty;
            }
            catch (ArgumentException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                _logger.LogError("The message could not be parsed - TRACE {0}", ex.ToString());
                Console.ResetColor();

                return string.Empty;
            }
            catch (HttpRequestException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                _logger.LogError("URL:{0} - TRACE {1}", url, ex.ToString());
                Console.ResetColor();

                return string.Empty;
            }
            catch (SocketException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                _logger.LogError("URL:{0} - TRACE {1}", url, ex.ToString());
                Console.ResetColor();

                return string.Empty;
            }
            catch (IOException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                _logger.LogError("URL:{0} - TRACE {1}", url, ex.ToString());
                Console.ResetColor();

                return string.Empty;
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                _logger.LogError("URL:{0} - TRACE {1}", url, ex.ToString());
                Console.ResetColor();

                return string.Empty;
            }
            finally
            {
            }
        }

        /// <summary>
        /// HTTP Client POST operation
        /// </summary>
        /// <param name="url"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        private async Task<bool> PostStringAsync(string url, HttpContent content)
        {
            try
            {
                CancellationToken cancellationToken = default;
                var httpResponse = _httpClient.PostAsync(url, content, cancellationToken).Result;
                if (!httpResponse.IsSuccessStatusCode)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    _logger.LogError(httpResponse.Content.ReadAsStringAsync().Result);
                    Console.ResetColor();
                    httpResponse.EnsureSuccessStatusCode();
                }

                return true;
            }
            catch (HttpRequestException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;

                _logger.LogError("URL:{0} - TRACE {1}", url, ex.ToString());

                Console.ResetColor();
                return false;
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;

                _logger.LogError("URL:{0} - TRACE {1}", url, ex.ToString());

                Console.ResetColor();
                return false;
            }
        }
    }
}
