﻿namespace AtionetMPPAExample
{
    public class MPPAHost
    {
        public string URL { get; set; }
        public string Controller { get; set; }
        public string SiteCode { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int Timeout { get; set; }
    }
}
