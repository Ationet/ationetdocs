﻿// See https://aka.ms/new-console-template for more information
using AtionetMPPAExample;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;

Console.WriteLine("Ationet MPPA Example!");
try
{
    var builder = Host.CreateApplicationBuilder(args);
    // NLog: Setup NLog for Dependency injection
    builder.Services.AddLogging(loggingBuilder =>
    {
        // configure Logging with NLog
        loggingBuilder.ClearProviders();
        loggingBuilder.AddNLog();  // NLog.Extensions.Logging v5 will automatically load from appsettings.json
    });


    var configuration = new ConfigurationBuilder()
    .SetBasePath(AppContext.BaseDirectory)
    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
    .Build();
    builder.Services.AddHostedService<MPPAClientWorker>();
    builder.Services.AddTransient((serviceProvider) => builder.Configuration.GetSection("MPPAHost").Get<MPPAHost>());

    var host = builder.Build();
    host.Run();

}
catch (Exception)
{

	throw;
}