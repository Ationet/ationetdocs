﻿namespace AtionetMPPAExample.MPPAHostRequest
{
    public class SiteData
    {
        public string name { get; set; }
        public List<SiteID> siteIDs { get; set; }
        public List<string> addressLines { get; set; }
    }
}
