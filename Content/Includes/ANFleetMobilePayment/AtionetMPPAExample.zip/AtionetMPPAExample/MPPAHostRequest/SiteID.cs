﻿namespace AtionetMPPAExample.MPPAHostRequest
{
    public class SiteID
    {
        public string type { get; set; }
        public string id { get; set; }
    }
}
