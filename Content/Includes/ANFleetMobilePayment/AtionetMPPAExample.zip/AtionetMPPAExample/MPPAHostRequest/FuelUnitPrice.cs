﻿namespace AtionetMPPAExample.MPPAHostRequest
{
    public class FuelUnitPrice
    {
        public string value { get; set; }
        public string currency { get; set; }
    }
}
