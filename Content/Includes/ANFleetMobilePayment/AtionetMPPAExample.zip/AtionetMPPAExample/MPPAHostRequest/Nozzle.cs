﻿namespace AtionetMPPAExample.MPPAHostRequest
{
    public class Nozzle
    {
        public string nozzleNo { get; set; }
        public string productNo { get; set; }
        public string tankNo1 { get; set; }
    }
}
