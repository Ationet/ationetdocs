﻿namespace AtionetMPPAExample.MPPAHostRequest
{
    public class DispensersConfiguration
    {
        public string dispenserID { get; set; }
        public List<FuelingPoint> fuelingPoints { get; set; }
    }
}
