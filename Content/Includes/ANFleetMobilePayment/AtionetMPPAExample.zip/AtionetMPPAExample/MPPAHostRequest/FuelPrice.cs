﻿
namespace AtionetMPPAExample.MPPAHostRequest
{
    public class FuelPrice
    {
        public string Value { get; set; }
        public string Currency { get; set; }
    }
}
