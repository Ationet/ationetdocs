﻿namespace AtionetMPPAExample.MPPAHostRequest
{
    public class MobileEvent
    {
        public string url { get; set; }

        public string errorCode { get; set; }

        public string endpointType { get; set; }
    }
}
