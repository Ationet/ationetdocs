﻿namespace AtionetMPPAExample.MPPAHostRequest
{
    public class FuelProducts
    {
        public List<FuelProduct> fuelProducts { get; set; }
    }
}
