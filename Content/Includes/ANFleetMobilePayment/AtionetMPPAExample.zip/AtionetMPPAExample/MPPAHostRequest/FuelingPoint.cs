﻿namespace AtionetMPPAExample.MPPAHostRequest
{
    public class FuelingPoint
    {
        public string fuelingPointID { get; set; }
        public List<Nozzle> nozzles { get; set; }
    }
}
