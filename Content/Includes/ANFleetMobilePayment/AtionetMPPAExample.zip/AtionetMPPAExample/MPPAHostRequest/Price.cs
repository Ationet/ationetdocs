﻿namespace AtionetMPPAExample.MPPAHostRequest
{
    public class Price
    {
        public FuelUnitPrice fuelUnitPrice { get; set; }
        public string priceTier { get; set; }
        public string modeNo { get; set; }
    }
}
