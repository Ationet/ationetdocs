﻿namespace AtionetMPPAExample.MPPAHostRequest
{
    public class DispensersConfigurations
    {
        public List<DispensersConfiguration> dispensersConfiguration { get; set; }
    }
}
