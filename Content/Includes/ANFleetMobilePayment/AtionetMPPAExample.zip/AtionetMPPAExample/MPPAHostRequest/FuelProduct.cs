﻿
namespace AtionetMPPAExample.MPPAHostRequest
{
    public class FuelProduct
    {
        public string ProductNo { get; set; }
        public string ProductName { get; set; }
        public string ProductCode { get; set; }
        public List<Price> Prices { get; set; }
        public FuelPrice FuelPrice { get; set; }
        public string FuelUnitOfMeasurement { get; set; }
        public string GradeAllowed { get; set; }
        public string MerchandiseCode { get; set; }
        public string TaxId { get; set; }
    }
}
