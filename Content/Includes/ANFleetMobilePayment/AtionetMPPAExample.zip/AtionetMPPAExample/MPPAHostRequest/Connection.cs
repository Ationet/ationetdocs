﻿namespace AtionetMPPAExample.MPPAHostRequest
{
    public class Connection
    {
        public string applicationSender { get; set; }

        public string workstationID { get; set; }

        public string timestamp { get; set; }

        public string interfaceVersion { get; set; }
    }

}
