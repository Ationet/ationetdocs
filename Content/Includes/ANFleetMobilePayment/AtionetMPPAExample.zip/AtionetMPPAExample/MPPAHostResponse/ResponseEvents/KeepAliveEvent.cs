﻿namespace AtionetMPPAExample.MPPAHostResponse.ResponseEvents
{
    public class KeepAliveEvent 
    {
        public string eventMessage { get; set; }
        public DateTime timestamp { get; set; }
    }
}
