﻿namespace AtionetMPPAExample.MPPAHostResponse.ResponseEvents
{
    public class AuthorizeRequestEvent
    {
        public string eventMessage { get; set; }
        public DateTime timestamp { get; set; }
        public string UMTI { get; set; }
    }
}
