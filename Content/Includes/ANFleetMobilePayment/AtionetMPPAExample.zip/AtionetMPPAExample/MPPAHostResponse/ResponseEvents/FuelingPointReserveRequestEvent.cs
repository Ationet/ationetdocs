﻿namespace AtionetMPPAExample.MPPAHostResponse.ResponseEvents
{
    public class FuelingPointReserveRequestEvent 
    {
        public string eventMessage { get; set; }
        public DateTime timestamp { get; set; }
        public string UMTI { get; set; }
        public string fuelingPointID { get; set; }
    }
}
