﻿namespace AtionetMPPAExample.MPPAHostResponse.ResponseEvents.EventsTypes
{
    public static class EventType
    {
        public const string SITE_DATA_REQUEST = "siteDataRequest";
        public const string FP_RESERVE_REQUEST = "FPReserveRequest";
        public const string FP_RESERVE_CANCEL_REQUEST = "FPReserveCancelRequest";
        public const string AUTHORIZE_REQUEST = "authorizeRequest";
        public const string CANCEL_TRX_REQUEST = "cancelTrxRequest";
        public const string TRANSACTION_DATA_REQUEST = "transactionDataRequest";
        public const string CLOSE_TRX_REQUEST = "closeTrxRequest";
        public const string KEEP_ALIVE = "keepAlive";
    }
}
